#import "hooks.h"
#import <substrate.h>
#import <Foundation/Foundation.h>

namespace hooks {
    void install_all() {
        // Все хуки установлены через %hook в Tweak.xm
        // Этот файл оставлен для будущих расширений
        NSLog(@"[Hack77] Hooks installed");
    }
}