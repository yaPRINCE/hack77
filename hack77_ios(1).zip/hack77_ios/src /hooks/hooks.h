#pragma once

namespace hooks {
    void install_all();
}