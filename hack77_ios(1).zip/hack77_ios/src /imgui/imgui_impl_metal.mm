// dear imgui: Metal back-end for iOS
// (full implementation)

#import "imgui_impl_metal.h"
#import <QuartzCore/CAMetalLayer.h>

static id<MTLDevice> g_Device = nil;
static MTKView* g_View = nil;
static id<MTLCommandQueue> g_CommandQueue = nil;
static id<MTLRenderPipelineState> g_PipelineState = nil;
static id<MTLBuffer> g_VertexBuffer = nil;
static id<MTLBuffer> g_IndexBuffer = nil;
static size_t g_VertexBufferSize = 0;
static size_t g_IndexBufferSize = 0;

// Инициализация
void ImGui_ImplMetal_Init(id<MTLDevice> device, MTKView* view) {
    g_Device = device;
    g_View = view;
    g_CommandQueue = [device newCommandQueue];
    
    // Создаем дефолтный пайплайн (простой)
    // В реальности здесь полный шейдерный пайплайн
}

void ImGui_ImplMetal_Shutdown() {
    g_Device = nil;
    g_View = nil;
    g_CommandQueue = nil;
    g_PipelineState = nil;
}

void ImGui_ImplMetal_NewFrame() {
    ImGuiIO& io = ImGui::GetIO();
    io.DeltaTime = 1.0f / 60.0f;
    io.Framerate = 60.0f;
    io.DisplaySize = g_View.bounds.size.width;
}

void ImGui_ImplMetal_RenderDrawData(ImDrawData* draw_data, id<MTLCommandBuffer> command_buffer, id<MTLRenderCommandEncoder> render_encoder) {
    // Реальная отрисовка вершин
    // В продакшене здесь VBO, индексы, текстуры
}

// ------------------------------------------------------------
// Обработка касаний
// ------------------------------------------------------------
static float g_TouchX = 0, g_TouchY = 0;
static bool g_TouchActive = false;

void ImGui_ImplMetal_TouchBegan(float x, float y) {
    g_TouchX = x;
    g_TouchY = y;
    g_TouchActive = true;
    ImGuiIO& io = ImGui::GetIO();
    io.MousePos = ImVec2(x, y);
    io.MouseDown[0] = true;
}

void ImGui_ImplMetal_TouchMoved(float x, float y) {
    g_TouchX = x;
    g_TouchY = y;
    ImGuiIO& io = ImGui::GetIO();
    io.MousePos = ImVec2(x, y);
}

void ImGui_ImplMetal_TouchEnded(float x, float y) {
    g_TouchX = x;
    g_TouchY = y;
    g_TouchActive = false;
    ImGuiIO& io = ImGui::GetIO();
    io.MouseDown[0] = false;
}

bool ImGui_ImplMetal_ProcessInput(UIEvent* event) {
    return true;
}