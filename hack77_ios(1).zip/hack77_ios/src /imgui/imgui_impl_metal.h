// dear imgui: Metal back-end for iOS
// (header)

#pragma once
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <UIKit/UIKit.h>

IMGUI_API void ImGui_ImplMetal_Init(id<MTLDevice> device, MTKView* view);
IMGUI_API void ImGui_ImplMetal_Shutdown();
IMGUI_API void ImGui_ImplMetal_NewFrame();
IMGUI_API void ImGui_ImplMetal_RenderDrawData(ImDrawData* draw_data, id<MTLCommandBuffer> command_buffer, id<MTLRenderCommandEncoder> render_encoder);
IMGUI_API bool ImGui_ImplMetal_ProcessInput(UIEvent* event);
IMGUI_API void ImGui_ImplMetal_TouchBegan(float x, float y);
IMGUI_API void ImGui_ImplMetal_TouchMoved(float x, float y);
IMGUI_API void ImGui_ImplMetal_TouchEnded(float x, float y);