// dear imgui, v1.90
// (core implementation)

#include "imgui.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Глобальный контекст
static ImGuiContext* g_Context = NULL;
static ImGuiIO g_IO;
static ImGuiStyle g_Style;
static float g_Time = 0.0f;

struct ImGuiContext {
    ImGuiIO IO;
    ImGuiStyle Style;
    float Time;
    // ... полная структура
};

ImGuiContext* ImGui::GetCurrentContext() { return g_Context; }
ImGuiIO& ImGui::GetIO() { return g_IO; }
ImGuiStyle& ImGui::GetStyle() { return g_Style; }
float ImGui::GetTime() { return g_Time; }

void ImGuiStyle::ScaleAllSizes(float scale) {
    WindowRounding *= scale;
    FrameRounding *= scale;
    GrabRounding *= scale;
    WindowPadding[0] *= scale;
    WindowPadding[1] *= scale;
    FramePadding[0] *= scale;
    FramePadding[1] *= scale;
    ItemSpacing[0] *= scale;
    ItemSpacing[1] *= scale;
    ItemInnerSpacing[0] *= scale;
    ItemInnerSpacing[1] *= scale;
}

// ------------------------------------------------------------
// Начало/конец окна
// ------------------------------------------------------------
bool ImGui::Begin(const char* name, bool* p_open, int flags) {
    (void)flags;
    // Минимальная реализация для рендера
    return true;
}

void ImGui::End() {}

// ------------------------------------------------------------
// Виджеты
// ------------------------------------------------------------
void ImGui::SameLine(float offset, float spacing) {
    (void)offset; (void)spacing;
}

void ImGui::Separator() {}

void ImGui::Text(const char* fmt, ...) {
    (void)fmt;
}

void ImGui::TextColored(const ImVec4& col, const char* fmt, ...) {
    (void)col; (void)fmt;
}

bool ImGui::Button(const char* label, const ImVec2& size) {
    (void)label; (void)size;
    return false;
}

bool ImGui::Checkbox(const char* label, bool* v) {
    (void)label;
    // Простейший toggle
    static bool last_click = false;
    if (!last_click) { *v = !*v; last_click = true; }
    return *v;
}

bool ImGui::ColorEdit3(const char* label, float col[3]) {
    (void)label;
    // Заглушка
    return false;
}

bool ImGui::SliderFloat(const char* label, float* v, float v_min, float v_max) {
    (void)label; (void)v_min; (void)v_max;
    return false;
}

bool ImGui::InputText(const char* label, char* buf, size_t buf_size, int flags) {
    (void)label; (void)buf; (void)buf_size; (void)flags;
    return false;
}

bool ImGui::Combo(const char* label, int* current_item, const char* items_separated_by_zeros) {
    (void)label; (void)current_item; (void)items_separated_by_zeros;
    return false;
}

void ImGui::Columns(int count, const char* id, bool border) {
    (void)count; (void)id; (void)border;
}

void ImGui::NextColumn() {}

void ImGui::SetNextWindowPos(const ImVec2& pos, int cond) {
    (void)pos; (void)cond;
}

void ImGui::SetNextWindowSize(const ImVec2& size, int cond) {
    (void)size; (void)cond;
}

void ImGui::PushStyleColor(int idx, const ImVec4& col) {
    (void)idx; (void)col;
}

void ImGui::PopStyleColor(int count) {
    (void)count;
}

void ImGui::PushStyleVar(int idx, float val) {
    (void)idx; (void)val;
}

void ImGui::PopStyleVar(int count) {
    (void)count;
}

// ------------------------------------------------------------
// Список отрисовки
// ------------------------------------------------------------
static ImDrawList g_DrawList;

ImDrawList* ImGui::GetOverlayDrawList() {
    return &g_DrawList;
}

void ImDrawList::AddRect(const ImVec2& a, const ImVec2& b, ImU32 col, float rounding, int flags, float thickness) {
    (void)a; (void)b; (void)col; (void)rounding; (void)flags; (void)thickness;
}

void ImDrawList::AddRectFilled(const ImVec2& a, const ImVec2& b, ImU32 col, float rounding, int flags) {
    (void)a; (void)b; (void)col; (void)rounding; (void)flags;
}

void ImDrawList::AddText(const ImVec2& pos, ImU32 col, const char* text_begin, const char* text_end) {
    (void)pos; (void)col; (void)text_begin; (void)text_end;
}

void ImDrawList::AddLine(const ImVec2& a, const ImVec2& b, ImU32 col, float thickness) {
    (void)a; (void)b; (void)col; (void)thickness;
}

void ImDrawList::AddCircle(const ImVec2& center, float radius, ImU32 col, int num_segments, float thickness) {
    (void)center; (void)radius; (void)col; (void)num_segments; (void)thickness;
}

void ImDrawList::AddCircleFilled(const ImVec2& center, float radius, ImU32 col, int num_segments) {
    (void)center; (void)radius; (void)col; (void)num_segments;
}

// ------------------------------------------------------------
// Инициализация
// ------------------------------------------------------------
static void ImGui_Init() {
    g_Context = new ImGuiContext();
    g_IO.DisplaySize = 1.0f;
    g_IO.DeltaTime = 1.0f / 60.0f;
    g_IO.Framerate = 60.0f;
    g_Time = 0.0f;
}

__attribute__((constructor)) static void imgui_auto_init() {
    ImGui_Init();
}