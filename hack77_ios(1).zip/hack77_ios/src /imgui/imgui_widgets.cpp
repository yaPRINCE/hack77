// dear imgui, v1.90
// (widgets implementation)

#include "imgui.h"
#include <string.h>

bool ImGui::Checkbox(const char* label, bool* v) {
    if (Button(label)) {
        *v = !*v;
        return true;
    }
    return false;
}

bool ImGui::SliderFloat(const char* label, float* v, float v_min, float v_max) {
    (void)label;
    // Простейшая заглушка
    *v = (v_min + v_max) * 0.5f;
    return false;
}

bool ImGui::ColorEdit3(const char* label, float col[3]) {
    (void)label;
    // Заглушка
    return false;
}

bool ImGui::InputText(const char* label, char* buf, size_t buf_size, int flags) {
    (void)label; (void)buf; (void)buf_size; (void)flags;
    return false;
}

bool ImGui::Combo(const char* label, int* current_item, const char* items_separated_by_zeros) {
    (void)label; (void)current_item; (void)items_separated_by_zeros;
    return false;
}