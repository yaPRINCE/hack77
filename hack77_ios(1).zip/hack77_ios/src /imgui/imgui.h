// dear imgui, v1.90
// (header)

#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <float.h>
#include <math.h>

#ifndef IMGUI_VERSION
#define IMGUI_VERSION "1.90"
#endif

#ifndef IM_ASSERT
#include <assert.h>
#define IM_ASSERT(_EXPR) assert(_EXPR)
#endif

#ifndef IM_DEBUG_BREAK
#if defined(_MSC_VER)
#define IM_DEBUG_BREAK() __debugbreak()
#else
#define IM_DEBUG_BREAK() __builtin_trap()
#endif
#endif

typedef unsigned int ImGuiID;
typedef unsigned short ImWchar16;
typedef unsigned int ImWchar32;
typedef ImWchar16 ImWchar;

// Основные типы
struct ImVec2 { float x, y; ImVec2() : x(0), y(0) {} ImVec2(float _x, float _y) : x(_x), y(_y) {} };
struct ImVec4 { float x, y, z, w; ImVec4() : x(0), y(0), z(0), w(0) {} ImVec4(float _x, float _y, float _z, float _w) : x(_x), y(_y), z(_z), w(_w) {} };

// Конфигурация
struct ImGuiIO {
    float DisplaySize;
    float DeltaTime;
    float Framerate;
    void* UserData;
    // ... полная структура в оригинальном imgui.h
};

// Стиль
struct ImGuiStyle {
    float WindowRounding;
    float FrameRounding;
    float GrabRounding;
    float WindowPadding[2];
    float FramePadding[2];
    float ItemSpacing[2];
    float ItemInnerSpacing[2];
    ImVec4 Colors[19];
    void ScaleAllSizes(float scale);
};

// Контекст
struct ImGuiContext;
ImGuiContext* ImGui::GetCurrentContext();
ImGuiIO& ImGui::GetIO();
ImGuiStyle& ImGui::GetStyle();

// API
namespace ImGui {
    bool Begin(const char* name, bool* p_open = NULL, int flags = 0);
    void End();
    void SameLine(float offset_from_start_x = 0.0f, float spacing = -1.0f);
    void Separator();
    void Text(const char* fmt, ...);
    void TextColored(const ImVec4& col, const char* fmt, ...);
    bool Button(const char* label, const ImVec2& size = ImVec2(0,0));
    bool Checkbox(const char* label, bool* v);
    bool ColorEdit3(const char* label, float col[3]);
    bool SliderFloat(const char* label, float* v, float v_min, float v_max);
    bool SliderAngle(const char* label, float* v_rad, float v_degrees_min = -360.0f, float v_degrees_max = +360.0f, const char* format = "%.0f deg");
    bool InputText(const char* label, char* buf, size_t buf_size, int flags = 0);
    bool Combo(const char* label, int* current_item, const char* items_separated_by_zeros);
    void Columns(int count = 1, const char* id = NULL, bool border = true);
    void NextColumn();
    void SetNextWindowPos(const ImVec2& pos, int cond = 0);
    void SetNextWindowSize(const ImVec2& size, int cond = 0);
    float GetTime();
    ImDrawList* GetOverlayDrawList();
    void PushStyleColor(int idx, const ImVec4& col);
    void PopStyleColor(int count = 1);
    void PushStyleVar(int idx, float val);
    void PopStyleVar(int count = 1);
}

struct ImDrawList {
    void AddRect(const ImVec2& a, const ImVec2& b, ImU32 col, float rounding = 0.0f, int flags = 0, float thickness = 1.0f);
    void AddRectFilled(const ImVec2& a, const ImVec2& b, ImU32 col, float rounding = 0.0f, int flags = 0);
    void AddText(const ImVec2& pos, ImU32 col, const char* text_begin, const char* text_end = NULL);
    void AddLine(const ImVec2& a, const ImVec2& b, ImU32 col, float thickness = 1.0f);
    void AddCircle(const ImVec2& center, float radius, ImU32 col, int num_segments = 0, float thickness = 1.0f);
    void AddCircleFilled(const ImVec2& center, float radius, ImU32 col, int num_segments = 0);
};

typedef unsigned int ImU32;
#define IM_COL32(r,g,b,a) (((ImU32)(a)<<24) | ((ImU32)(b)<<16) | ((ImU32)(g)<<8) | (ImU32)(r))