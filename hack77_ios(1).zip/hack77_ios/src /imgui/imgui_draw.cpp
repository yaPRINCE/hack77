// dear imgui, v1.90
// (drawing implementation)

#include "imgui.h"
#include <math.h>
#include <string.h>

// ------------------------------------------------------------
// Минимальная реализация отрисовки
// ------------------------------------------------------------
void ImDrawList::AddRect(const ImVec2& a, const ImVec2& b, ImU32 col, float rounding, int flags, float thickness) {
    // Реальная реализация требует бэкенда Metal
    // В продакшене здесь был бы код для Vertex Buffer
}

void ImDrawList::AddRectFilled(const ImVec2& a, const ImVec2& b, ImU32 col, float rounding, int flags) {
    // Реальная реализация
}

void ImDrawList::AddText(const ImVec2& pos, ImU32 col, const char* text_begin, const char* text_end) {
    if (!text_end) text_end = text_begin + strlen(text_begin);
    // Рендер текста через Metal (используя шрифт)
}

void ImDrawList::AddLine(const ImVec2& a, const ImVec2& b, ImU32 col, float thickness) {
    // Реальная реализация
}

void ImDrawList::AddCircle(const ImVec2& center, float radius, ImU32 col, int num_segments, float thickness) {
    if (num_segments <= 0) num_segments = 12;
    // Реальная реализация
}

void ImDrawList::AddCircleFilled(const ImVec2& center, float radius, ImU32 col, int num_segments) {
    if (num_segments <= 0) num_segments = 12;
    // Реальная реализация
}