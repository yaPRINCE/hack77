// dear imgui, v1.90
// (tables implementation - заглушка для iOS)

#include "imgui.h"

void ImGui::Columns(int count, const char* id, bool border) {
    (void)count; (void)id; (void)border;
}

void ImGui::NextColumn() {
    // Просто пропускаем
}

int ImGui::GetColumnIndex() {
    return 0;
}

float ImGui::GetColumnWidth(int column_index) {
    (void)column_index;
    return 100.0f;
}

void ImGui::SetColumnWidth(int column_index, float width) {
    (void)column_index; (void)width;
}