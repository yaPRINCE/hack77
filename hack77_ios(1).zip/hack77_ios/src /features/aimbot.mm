#import "aimbot.h"
#import "../menu/menu.h"
#import "../utils/memory.h"
#import "../utils/math.h"
#import <UIKit/UIKit.h>

namespace aimbot {
    static Vector2 target_angle = {0,0};
    static bool target_exists = false;
    
    void update_touch_assist(Vector2 touch_pos) {
        if (!menu::aim.enabled || !menu::aim.aim_assist_touch) return;
        
        float best_dist = menu::aim.aim_radius;
        Player* best = nullptr;
        
        auto players = memory::get_player_list();
        for (auto& p : players) {
            if (!p.is_alive || p.is_teammate) continue;
            Vector2 head_screen;
            if (!math::world_to_screen(p.head_pos, head_screen)) continue;
            float d = sqrtf(powf(touch_pos.x - head_screen.x, 2) + powf(touch_pos.y - head_screen.y, 2));
            if (d < best_dist) {
                best_dist = d;
                best = &p;
            }
        }
        
        if (best) {
            Vector3 target_world = best->head_pos;
            if (menu::aim.prediction) {
                target_world += best->velocity * (menu::aim.prediction_ms / 1000.0f);
            }
            Vector3 local_pos = memory::get_local_player().position;
            Vector3 delta = target_world - local_pos;
            float pitch = -asin(delta.y / delta.length()) * (180.0f / M_PI);
            float yaw = atan2(delta.x, delta.z) * (180.0f / M_PI);
            target_angle = {pitch, yaw};
            target_exists = true;
            
            Vector3 current = memory::get_view_angles();
            Vector3 diff = target_angle - current;
            float smooth_factor = menu::aim.smooth / 20.0f;
            Vector3 new_angle = current + diff * smooth_factor;
            memory::set_view_angles(new_angle);
        } else {
            target_exists = false;
        }
    }
    
    bool has_target() { return target_exists; }
    Vector2 get_target_angle() { return target_angle; }
}