#import "esp.h"
#import "../menu/menu.h"
#import "../utils/memory.h"
#import "../utils/math.h"
#import <ImGui/imgui.h>

namespace esp {
    void render_players() {
        if (!menu::esp.enabled) return;
        
        auto players = memory::get_player_list();
        for (auto& p : players) {
            if (!p.is_alive || p.is_dummy) continue;
            if (p.distance > menu::esp.max_distance) continue;
            
            ImColor col;
            if (menu::esp.enemy_color.rainbow) {
                float t = ImGui::GetTime() * menu::esp.enemy_color.rainbow_speed;
                col = ImColor(sinf(t)*0.5f+0.5f, sinf(t+2.094f)*0.5f+0.5f, sinf(t+4.188f)*0.5f+0.5f, 1.0f);
            } else {
                col = ImColor(menu::esp.enemy_color.r, menu::esp.enemy_color.g, menu::esp.enemy_color.b, 1.0f);
            }
            
            Vector2 head_screen, feet_screen;
            if (!math::world_to_screen(p.head_pos, head_screen)) continue;
            if (!math::world_to_screen(p.feet_pos, feet_screen)) continue;
            
            float height = feet_screen.y - head_screen.y;
            float width = height * 0.45f;
            
            if (menu::esp.box_2d) {
                ImVec2 tl = ImVec2(head_screen.x - width/2, head_screen.y);
                ImVec2 br = ImVec2(head_screen.x + width/2, feet_screen.y);
                ImGui::GetOverlayDrawList()->AddRect(tl, br, col, 2.0f, 0, 1.5f);
            }
            
            if (menu::esp.health_bar) {
                float ratio = p.health / 100.0f;
                ImVec2 hp_pos = ImVec2(head_screen.x - width/2 - 6, head_screen.y);
                ImGui::GetOverlayDrawList()->AddRectFilled(hp_pos, ImVec2(hp_pos.x + 4, hp_pos.y + height), IM_COL32(0,0,0,180));
                ImGui::GetOverlayDrawList()->AddRectFilled(
                    ImVec2(hp_pos.x, hp_pos.y + height*(1-ratio)), 
                    ImVec2(hp_pos.x + 4, hp_pos.y + height), 
                    IM_COL32(0,255,0,255));
            }
            
            if (menu::esp.name) {
                ImGui::GetOverlayDrawList()->AddText(ImVec2(head_screen.x - width/2, head_screen.y - 20), col, p.name.c_str());
            }
            
            if (menu::esp.distance) {
                char buf[32]; snprintf(buf, 32, "%.0fm", p.distance);
                ImGui::GetOverlayDrawList()->AddText(ImVec2(head_screen.x - width/2, feet_screen.y + 4), IM_COL32(255,255,255,200), buf);
            }
        }
    }
}