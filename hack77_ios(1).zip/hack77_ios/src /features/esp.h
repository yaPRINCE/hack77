#pragma once
#include <vector>
#include <string>

struct Player {
    std::string name;
    float health;
    int team_id;
    bool is_alive;
    bool is_teammate;
    bool is_dummy;
    float distance;
    Vector3 position;
    Vector3 head_pos;
    Vector3 feet_pos;
    Vector3 velocity;
    Vector3 bones[20];
};

namespace esp {
    void render_players();
    void draw_box(Vector2 top, Vector2 bottom, ImColor color);
    void draw_health(Vector2 pos, float health);
    void draw_text(const char* text, Vector2 pos, ImColor color = IM_COL32(255,255,255,255));
    void draw_skeleton(Vector3* bones, ImColor color);
}