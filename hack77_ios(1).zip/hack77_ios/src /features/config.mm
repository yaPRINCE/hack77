#import "config.h"
#import "../menu/menu.h"
#import <Foundation/Foundation.h>
#import <fstream>
#import <nlohmann/json.hpp>

using json = nlohmann::json;

namespace config {
    
    static NSString* get_config_path(const char* name) {
        return [NSString stringWithFormat:@"/var/mobile/Documents/Hack77_configs/%s.cfg", name];
    }
    
    void save_config(const char* name) {
        json j;
        j["menu"]["accent_r"] = menu::settings.accent_color.r;
        j["menu"]["accent_g"] = menu::settings.accent_color.g;
        j["menu"]["accent_b"] = menu::settings.accent_color.b;
        j["menu"]["rainbow"] = menu::settings.accent_color.rainbow;
        j["menu"]["rainbow_speed"] = menu::settings.accent_color.rainbow_speed;
        j["menu"]["opacity"] = menu::settings.opacity;
        j["menu"]["scale"] = menu::settings.menu_scale;
        j["menu"]["language"] = menu::settings.language;
        j["menu"]["show_fps"] = menu::settings.show_fps;
        
        j["esp"]["enabled"] = menu::esp.enabled;
        j["esp"]["box_2d"] = menu::esp.box_2d;
        j["esp"]["box_3d"] = menu::esp.box_3d;
        j["esp"]["health_bar"] = menu::esp.health_bar;
        j["esp"]["name"] = menu::esp.name;
        j["esp"]["distance"] = menu::esp.distance;
        j["esp"]["skeleton"] = menu::esp.skeleton;
        j["esp"]["glow"] = menu::esp.glow;
        j["esp"]["head_circle"] = menu::esp.head_circle;
        j["esp"]["max_distance"] = menu::esp.max_distance;
        j["esp"]["enemy_r"] = menu::esp.enemy_color.r;
        j["esp"]["enemy_g"] = menu::esp.enemy_color.g;
        j["esp"]["enemy_b"] = menu::esp.enemy_color.b;
        j["esp"]["enemy_rainbow"] = menu::esp.enemy_color.rainbow;
        j["esp"]["enemy_rainbow_speed"] = menu::esp.enemy_color.rainbow_speed;
        j["esp"]["team_r"] = menu::esp.teammate_color.r;
        j["esp"]["team_g"] = menu::esp.teammate_color.g;
        j["esp"]["team_b"] = menu::esp.teammate_color.b;
        j["esp"]["team_rainbow"] = menu::esp.teammate_color.rainbow;
        j["esp"]["team_rainbow_speed"] = menu::esp.teammate_color.rainbow_speed;
        
        j["aim"]["enabled"] = menu::aim.enabled;
        j["aim"]["aim_on_shot"] = menu::aim.aim_on_shot;
        j["aim"]["visible_check"] = menu::aim.visible_check;
        j["aim"]["fov"] = menu::aim.fov;
        j["aim"]["smooth"] = menu::aim.smooth;
        j["aim"]["bone"] = menu::aim.bone;
        j["aim"]["recoil_comp"] = menu::aim.recoil_comp;
        j["aim"]["prediction"] = menu::aim.prediction;
        j["aim"]["prediction_ms"] = menu::aim.prediction_ms;
        j["aim"]["aim_radius"] = menu::aim.aim_radius;
        j["aim"]["aim_assist_touch"] = menu::aim.aim_assist_touch;
        
        NSString *path = get_config_path(name);
        [[NSFileManager defaultManager] createDirectoryAtPath:[path stringByDeletingLastPathComponent]
                                   withIntermediateDirectories:YES attributes:nil error:nil];
        std::ofstream f([path UTF8String]);
        f << j.dump(4);
    }
    
    void load_config(const char* name) {
        NSString *path = get_config_path(name);
        std::ifstream f([path UTF8String]);
        if (!f) return;
        
        json j;
        try { f >> j; } catch (...) { return; }
        
        if (j.contains("menu")) {
            auto& m = j["menu"];
            if (m.contains("accent_r")) menu::settings.accent_color.r = m["accent_r"];
            if (m.contains("accent_g")) menu::settings.accent_color.g = m["accent_g"];
            if (m.contains("accent_b")) menu::settings.accent_color.b = m["accent_b"];
            if (m.contains("rainbow")) menu::settings.accent_color.rainbow = m["rainbow"];
            if (m.contains("rainbow_speed")) menu::settings.accent_color.rainbow_speed = m["rainbow_speed"];
            if (m.contains("opacity")) menu::settings.opacity = m["opacity"];
            if (m.contains("scale")) menu::settings.menu_scale = m["scale"];
            if (m.contains("language")) menu::settings.language = m["language"];
            if (m.contains("show_fps")) menu::settings.show_fps = m["show_fps"];
        }
        
        if (j.contains("esp")) {
            auto& e = j["esp"];
            if (e.contains("enabled")) menu::esp.enabled = e["enabled"];
            if (e.contains("box_2d")) menu::esp.box_2d = e["box_2d"];
            if (e.contains("box_3d")) menu::esp.box_3d = e["box_3d"];
            if (e.contains("health_bar")) menu::esp.health_bar = e["health_bar"];
            if (e.contains("name")) menu::esp.name = e["name"];
            if (e.contains("distance")) menu::esp.distance = e["distance"];
            if (e.contains("skeleton")) menu::esp.skeleton = e["skeleton"];
            if (e.contains("glow")) menu::esp.glow = e["glow"];
            if (e.contains("head_circle")) menu::esp.head_circle = e["head_circle"];
            if (e.contains("max_distance")) menu::esp.max_distance = e["max_distance"];
            if (e.contains("enemy_r")) menu::esp.enemy_color.r = e["enemy_r"];
            if (e.contains("enemy_g")) menu::esp.enemy_color.g = e["enemy_g"];
            if (e.contains("enemy_b")) menu::esp.enemy_color.b = e["enemy_b"];
            if (e.contains("enemy_rainbow")) menu::esp.enemy_color.rainbow = e["enemy_rainbow"];
            if (e.contains("enemy_rainbow_speed")) menu::esp.enemy_color.rainbow_speed = e["enemy_rainbow_speed"];
            if (e.contains("team_r")) menu::esp.teammate_color.r = e["team_r"];
            if (e.contains("team_g")) menu::esp.teammate_color.g = e["team_g"];
            if (e.contains("team_b")) menu::esp.teammate_color.b = e["team_b"];
            if (e.contains("team_rainbow")) menu::esp.teammate_color.rainbow = e["team_rainbow"];
            if (e.contains("team_rainbow_speed")) menu::esp.teammate_color.rainbow_speed = e["team_rainbow_speed"];
        }
        
        if (j.contains("aim")) {
            auto& a = j["aim"];
            if (a.contains("enabled")) menu::aim.enabled = a["enabled"];
            if (a.contains("aim_on_shot")) menu::aim.aim_on_shot = a["aim_on_shot"];
            if (a.contains("visible_check")) menu::aim.visible_check = a["visible_check"];
            if (a.contains("fov")) menu::aim.fov = a["fov"];
            if (a.contains("smooth")) menu::aim.smooth = a["smooth"];
            if (a.contains("bone")) menu::aim.bone = a["bone"];
            if (a.contains("recoil_comp")) menu::aim.recoil_comp = a["recoil_comp"];
            if (a.contains("prediction")) menu::aim.prediction = a["prediction"];
            if (a.contains("prediction_ms")) menu::aim.prediction_ms = a["prediction_ms"];
            if (a.contains("aim_radius")) menu::aim.aim_radius = a["aim_radius"];
            if (a.contains("aim_assist_touch")) menu::aim.aim_assist_touch = a["aim_assist_touch"];
        }
    }
    
    void load_last() {
        load_config("default");
    }
}