#pragma once
#include "../utils/math.h"

namespace aimbot {
    void update_touch_assist(Vector2 touch_pos);
    void update_aimbot();
    bool has_target();
    Vector2 get_target_angle();
}