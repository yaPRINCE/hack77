#pragma once

namespace config {
    void save_config(const char* name);
    void load_config(const char* name);
    void load_last();
}