#import "pattern_scan.h"
#import "memory.h"
#import <mach-o/loader.h>
#import <mach-o/nlist.h>

namespace pattern_scan {
    uintptr_t find_pattern(const char* pattern, const char* mask, int len) {
        uintptr_t base = memory::get_base_address();
        uintptr_t end = base + 0x1000000; // 16MB предел
        
        for (uintptr_t addr = base; addr < end; addr++) {
            bool found = true;
            for (int i = 0; i < len; i++) {
                if (mask[i] == 'x' && *(unsigned char*)(addr + i) != (unsigned char)pattern[i]) {
                    found = false;
                    break;
                }
            }
            if (found) return addr;
        }
        return 0;
    }
}