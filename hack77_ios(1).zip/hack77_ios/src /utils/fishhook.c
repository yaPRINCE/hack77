#include "fishhook.h"
#include <mach-o/getsect.h>
#include <mach-o/dyld.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

static void perform_rebinding_with_section(struct rebinding* rebindings, size_t rebindings_count, struct section_64* section, intptr_t slide) {
    if (!section) return;
    
    uintptr_t* indirect_symbol_addresses = (uintptr_t*)(section->addr + slide);
    uint32_t* indirect_symbol_indices = (uint32_t*)(section->reserved1 + (uintptr_t)section + slide);
    
    // Получаем символы
    struct mach_header_64* header = (struct mach_header_64*)_dyld_get_image_header(0);
    struct symtab_command* symtab = NULL;
    struct dysymtab_command* dysymtab = NULL;
    struct load_command* lc = (struct load_command*)(header + 1);
    
    for (uint32_t i = 0; i < header->ncmds; i++) {
        if (lc->cmd == LC_SYMTAB) {
            symtab = (struct symtab_command*)lc;
        } else if (lc->cmd == LC_DYSYMTAB) {
            dysymtab = (struct dysymtab_command*)lc;
        }
        lc = (struct load_command*)((uintptr_t)lc + lc->cmdsize);
    }
    
    if (!symtab || !dysymtab) return;
    
    char* strtab = (char*)(symtab->stroff + slide);
    struct nlist_64* symtab_ptr = (struct nlist_64*)(symtab->symoff + slide);
    uint32_t* indirect_indices = (uint32_t*)(dysymtab->indirectsymoff + slide);
    
    for (uint32_t i = 0; i < dysymtab->nindirectsyms; i++) {
        uint32_t sym_index = indirect_indices[i];
        if (sym_index == INDIRECT_SYMBOL_ABS || sym_index == INDIRECT_SYMBOL_LOCAL) continue;
        
        const char* symbol_name = strtab + symtab_ptr[sym_index].n_un.n_strx;
        
        for (size_t j = 0; j < rebindings_count; j++) {
            if (strcmp(symbol_name, rebindings[j].name) == 0) {
                *rebindings[j].replaced = (void*)indirect_symbol_addresses[i];
                indirect_symbol_addresses[i] = (uintptr_t)rebindings[j].replacement;
                break;
            }
        }
    }
}

int rebind_symbols(struct rebinding rebindings[], size_t rebindings_count) {
    intptr_t slide = _dyld_get_image_vmaddr_slide(0);
    struct mach_header_64* header = (struct mach_header_64*)_dyld_get_image_header(0);
    
    // Перехват в __DATA сегменте
    struct section_64* section = getsectbynamefromheader_64(header, "__DATA", "__la_symbol_ptr");
    if (section) {
        perform_rebinding_with_section(rebindings, rebindings_count, section, slide);
    }
    
    section = getsectbynamefromheader_64(header, "__DATA", "__nl_symbol_ptr");
    if (section) {
        perform_rebinding_with_section(rebindings, rebindings_count, section, slide);
    }
    
    return 0;
}