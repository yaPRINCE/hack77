#pragma once
#include <cmath>
#define M_PI 3.14159265358979323846f

struct Vector2 { float x, y; Vector2(float _x=0,float _y=0):x(_x),y(_y){} };
struct Vector3 { float x, y, z; Vector3(float _x=0,float _y=0,float _z=0):x(_x),y(_y),z(_z){} };
struct Vector4 { float x, y, z, w; };

inline Vector3 operator+(const Vector3& a, const Vector3& b) { return {a.x+b.x, a.y+b.y, a.z+b.z}; }
inline Vector3 operator-(const Vector3& a, const Vector3& b) { return {a.x-b.x, a.y-b.y, a.z-b.z}; }
inline Vector3 operator*(const Vector3& a, float s) { return {a.x*s, a.y*s, a.z*s}; }
inline float length(const Vector3& v) { return sqrtf(v.x*v.x + v.y*v.y + v.z*v.z); }

namespace math {
    bool world_to_screen(Vector3 world, Vector2& screen);
    Vector3 angle_from_delta(Vector3 delta);
    float distance(Vector3 a, Vector3 b);
}