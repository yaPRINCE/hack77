#import "memory.h"
#import "offsets.h"
#import <mach/mach.h>
#import <dlfcn.h>
#import <UIKit/UIKit.h>

namespace memory {
    static task_t task = mach_task_self();
    static uintptr_t base_addr = 0;
    
    uintptr_t get_base_address() {
        if (base_addr) return base_addr;
        Dl_info info;
        dladdr((void*)&get_base_address, &info);
        base_addr = (uintptr_t)info.dli_fbase;
        return base_addr;
    }
    
    template <typename T>
    T read(uintptr_t addr) {
        T val;
        vm_size_t size = sizeof(T);
        vm_read_overwrite(task, addr, size, (vm_address_t)&val, &size);
        return val;
    }
    template float read<float>(uintptr_t);
    template int read<int>(uintptr_t);
    template bool read<bool>(uintptr_t);
    template uintptr_t read<uintptr_t>(uintptr_t);
    template Vector3 read<Vector3>(uintptr_t);
    
    template <typename T>
    void write(uintptr_t addr, T val) {
        vm_size_t size = sizeof(T);
        vm_write(task, addr, (vm_address_t)&val, size);
    }
    template void write<float>(uintptr_t, float);
    template void write<int>(uintptr_t, int);
    template void write<Vector3>(uintptr_t, Vector3);
    
    Player get_local_player() {
        Player p;
        uintptr_t world = read<uintptr_t>(get_base_address() + offsets::GWorld);
        if (!world) return p;
        uintptr_t local = read<uintptr_t>(world + offsets::LocalPlayer);
        if (!local) return p;
        p.health = read<float>(local + offsets::Health);
        p.team_id = read<int>(local + offsets::TeamID);
        p.position = read<Vector3>(local + offsets::Position);
        p.is_alive = p.health > 0;
        return p;
    }
    
    std::vector<Player> get_player_list() {
        std::vector<Player> result;
        uintptr_t world = read<uintptr_t>(get_base_address() + offsets::GWorld);
        if (!world) return result;
        uintptr_t entity_list = read<uintptr_t>(world + offsets::EntityList);
        int max_players = read<int>(world + offsets::MaxPlayers);
        
        Player local = get_local_player();
        
        for (int i = 0; i < max_players; i++) {
            uintptr_t player = read<uintptr_t>(entity_list + i * 8);
            if (!player) continue;
            Player p;
            p.health = read<float>(player + offsets::Health);
            p.is_alive = p.health > 0;
            if (!p.is_alive) continue;
            p.team_id = read<int>(player + offsets::TeamID);
            p.position = read<Vector3>(player + offsets::Position);
            p.velocity = read<Vector3>(player + offsets::Velocity);
            p.head_pos = p.position + Vector3{0, 1.7f, 0};
            p.feet_pos = p.position;
            p.distance = (p.position - local.position).length();
            p.is_teammate = (p.team_id == local.team_id);
            uintptr_t name_ptr = read<uintptr_t>(player + offsets::NamePtr);
            if (name_ptr) p.name = std::string((char*)name_ptr);
            result.push_back(p);
        }
        return result;
    }
    
    Vector3 get_view_angles() {
        uintptr_t world = read<uintptr_t>(get_base_address() + offsets::GWorld);
        return read<Vector3>(world + offsets::ViewMatrix + 0x40);
    }
    
    void set_view_angles(Vector3 angles) {
        uintptr_t world = read<uintptr_t>(get_base_address() + offsets::GWorld);
        write<Vector3>(world + offsets::ViewMatrix + 0x40, angles);
    }
}