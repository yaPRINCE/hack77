#import "math.h"
#import "memory.h"
#import "offsets.h"
#import <UIKit/UIKit.h>

namespace math {
    bool world_to_screen(Vector3 world, Vector2& screen) {
        uintptr_t base = memory::get_base_address();
        uintptr_t world_ptr = memory::read<uintptr_t>(base + offsets::GWorld);
        if (!world_ptr) return false;
        
        float* vm = (float*)(world_ptr + offsets::ViewMatrix);
        Vector4 clip = {
            world.x * vm[0] + world.y * vm[4] + world.z * vm[8] + vm[12],
            world.x * vm[1] + world.y * vm[5] + world.z * vm[9] + vm[13],
            world.x * vm[2] + world.y * vm[6] + world.z * vm[10] + vm[14],
            world.x * vm[3] + world.y * vm[7] + world.z * vm[11] + vm[15]
        };
        
        if (clip.w < 0.1f) return false;
        
        Vector3 ndc = {clip.x/clip.w, clip.y/clip.w, clip.z/clip.w};
        CGSize size = [UIScreen mainScreen].bounds.size;
        screen.x = (ndc.x + 1.0f) * 0.5f * size.width;
        screen.y = (1.0f - ndc.y) * 0.5f * size.height;
        return true;
    }
    
    float distance(Vector3 a, Vector3 b) {
        return length(b - a);
    }
}