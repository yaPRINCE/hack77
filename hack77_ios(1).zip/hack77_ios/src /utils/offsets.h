#pragma once
#include <cstdint>

namespace offsets {
    // Standoff 2 iOS (обновлять под версию)
    static const uintptr_t GWorld = 0x7B8B8C8;
    static const uintptr_t EntityList = 0x1B0;
    static const uintptr_t LocalPlayer = 0x1B8;
    static const uintptr_t ViewMatrix = 0x2D8;
    static const uintptr_t Health = 0x1F8;
    static const uintptr_t TeamID = 0x1EC;
    static const uintptr_t Position = 0xE8;
    static const uintptr_t Velocity = 0x100;
    static const uintptr_t NamePtr = 0x1A8;
    static const uintptr_t MaxPlayers = 0x1C0;
}