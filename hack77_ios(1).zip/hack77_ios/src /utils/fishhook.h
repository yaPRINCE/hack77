#pragma once
#include <mach-o/dyld.h>
#include <mach-o/loader.h>

#ifdef __cplusplus
extern "C" {
#endif

struct rebinding {
    const char* name;
    void* replacement;
    void** replaced;
};

int rebind_symbols(struct rebinding rebindings[], size_t rebindings_count);

#ifdef __cplusplus
}
#endif