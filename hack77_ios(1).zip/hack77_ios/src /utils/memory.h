#pragma once
#include <vector>
#include <string>
#include "../utils/math.h"

struct Player {
    std::string name;
    float health;
    int team_id;
    bool is_alive;
    bool is_teammate;
    bool is_dummy;
    float distance;
    Vector3 position;
    Vector3 head_pos;
    Vector3 feet_pos;
    Vector3 velocity;
    Vector3 bones[20];
};

namespace memory {
    uintptr_t get_base_address();
    template <typename T> T read(uintptr_t addr);
    template <typename T> void write(uintptr_t addr, T val);
    std::vector<Player> get_player_list();
    Player get_local_player();
    Vector3 get_view_angles();
    void set_view_angles(Vector3 angles);
    bool world_to_screen(Vector3 world, Vector2& screen);
}