#import "menu.h"
#import "../imgui/imgui_impl_metal.h"
#import <UIKit/UIKit.h>
#import <MetalKit/MetalKit.h>

static UIView* g_RenderView = nil;
static id<MTLCommandQueue> g_CommandQueue = nil;

namespace render {

void start_with_view(UIView* view) {
    g_RenderView = view;
    MTKView* mtkView = (MTKView*)view;
    g_CommandQueue = [mtkView.device newCommandQueue];
    ImGui_ImplMetal_Init(mtkView.device, mtkView);
    menu::init_style_midnight();
    NSLog(@"[Hack77] Render initialized");
}

void draw_frame() {
    if (!g_RenderView) return;
    ImGui_ImplMetal_NewFrame();
    menu::render_menu();
    // Рендер через Metal (реализация в imgui_impl_metal)
}

void touch_began(float x, float y) {
    ImGui_ImplMetal_TouchBegan(x, y);
}

void touch_moved(float x, float y) {
    ImGui_ImplMetal_TouchMoved(x, y);
}

void touch_ended(float x, float y) {
    ImGui_ImplMetal_TouchEnded(x, y);
}

} // namespace render