#pragma once
#import <ImGui/imgui.h>
#include <string>
#include <vector>

namespace menu {

    struct Color {
        float r,g,b,a;
        bool rainbow;
        float rainbow_speed;
        Color() : r(0.0f), g(0.8f), b(1.0f), a(1.0f), rainbow(false), rainbow_speed(1.0f) {}
        Color(float _r, float _g, float _b, float _a, bool _rainbow = false, float _speed = 1.0f)
            : r(_r), g(_g), b(_b), a(_a), rainbow(_rainbow), rainbow_speed(_speed) {}
    };

    struct Settings {
        bool menu_open = false;
        int active_tab = 0;
        Color accent_color {0.0f, 0.8f, 1.0f, 1.0f, false, 1.2f};
        bool rainbow_accent = false;
        std::string language = "EN";
        float menu_scale = 1.0f;
        float opacity = 0.85f;
        bool show_fps = true;
    };

    struct EspConfig {
        bool enabled = true;
        bool box_2d = true;
        bool box_3d = false;
        bool health_bar = true;
        bool name = true;
        bool distance = true;
        bool skeleton = false;
        bool glow = true;
        bool head_circle = false;
        float max_distance = 150.0f;
        Color enemy_color {1.0f, 0.15f, 0.15f, 1.0f, false, 1.5f};
        Color teammate_color {0.15f, 0.9f, 0.15f, 1.0f, false, 1.5f};
        Color glow_color {0.0f, 0.6f, 1.0f, 0.7f, true, 0.8f};
    };

    struct AimbotConfig {
        bool enabled = true;
        bool aim_on_shot = false;
        bool visible_check = true;
        float fov = 30.0f;
        float smooth = 5.0f;
        int bone = 0;
        float recoil_comp = 0.7f;
        bool prediction = true;
        float prediction_ms = 50.0f;
        float aim_radius = 60.0f;
        bool aim_assist_touch = true;
    };

    extern Settings settings;
    extern EspConfig esp;
    extern AimbotConfig aim;

    void init_style_midnight();
    void render_menu();
    void render_visual_tab();
    void render_aim_tab();
    void render_settings_tab();
    void update_rainbow_colors(float delta_time);
}

namespace render {
    void start_with_view(UIView *view);
    void draw_frame();
    void touch_began(float x, float y);
    void touch_moved(float x, float y);
    void touch_ended(float x, float y);
}

namespace config {
    void save_config(const char* name);
    void load_config(const char* name);
    void load_last();
}