#import "menu.h"
#import <UIKit/UIKit.h>
#include <cmath>

namespace menu {
    Settings settings;
    EspConfig esp;
    AimbotConfig aim;
}

void menu::init_style_midnight() {
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 10.0f;
    style.FrameRounding = 6.0f;
    style.GrabRounding = 4.0f;
    style.WindowPadding = ImVec2(15, 15);
    style.FramePadding = ImVec2(10, 6);
    style.ItemSpacing = ImVec2(10, 8);
    style.ItemInnerSpacing = ImVec2(6, 4);
    
    auto& c = style.Colors;
    c[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.06f, 0.09f, menu::settings.opacity);
    c[ImGuiCol_TitleBg] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
    c[ImGuiCol_TitleBgActive] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
    c[ImGuiCol_MenuBarBg] = ImVec4(0.08f, 0.08f, 0.12f, 0.9f);
    c[ImGuiCol_Header] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.35f);
    c[ImGuiCol_HeaderHovered] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.55f);
    c[ImGuiCol_HeaderActive] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.75f);
    c[ImGuiCol_Button] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.20f);
    c[ImGuiCol_ButtonHovered] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.45f);
    c[ImGuiCol_ButtonActive] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.65f);
    c[ImGuiCol_CheckMark] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 1.0f);
    c[ImGuiCol_SliderGrab] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.8f);
    c[ImGuiCol_SliderGrabActive] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 1.0f);
    c[ImGuiCol_FrameBg] = ImVec4(0.10f, 0.10f, 0.14f, 0.7f);
    c[ImGuiCol_FrameBgHovered] = ImVec4(0.15f, 0.15f, 0.20f, 0.9f);
    c[ImGuiCol_FrameBgActive] = ImVec4(0.20f, 0.20f, 0.28f, 1.0f);
    c[ImGuiCol_Text] = ImVec4(0.92f, 0.92f, 0.97f, 1.0f);
    c[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.55f, 1.0f);
    c[ImGuiCol_Separator] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.3f);
    c[ImGuiCol_Border] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.2f);
    c[ImGuiCol_Tab] = ImVec4(0.08f, 0.08f, 0.12f, 0.7f);
    c[ImGuiCol_TabHovered] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.35f);
    c[ImGuiCol_TabActive] = ImVec4(menu::settings.accent_color.r, menu::settings.accent_color.g, menu::settings.accent_color.b, 0.55f);
}

void menu::update_rainbow_colors(float delta) {
    if (settings.accent_color.rainbow) {
        float t = ImGui::GetTime() * settings.accent_color.rainbow_speed;
        settings.accent_color.r = sinf(t) * 0.5f + 0.5f;
        settings.accent_color.g = sinf(t + 2.094f) * 0.5f + 0.5f;
        settings.accent_color.b = sinf(t + 4.188f) * 0.5f + 0.5f;
    }
    if (esp.enemy_color.rainbow) {
        float t = ImGui::GetTime() * esp.enemy_color.rainbow_speed;
        esp.enemy_color.r = sinf(t) * 0.5f + 0.5f;
        esp.enemy_color.g = sinf(t + 2.094f) * 0.5f + 0.5f;
        esp.enemy_color.b = sinf(t + 4.188f) * 0.5f + 0.5f;
    }
    if (esp.teammate_color.rainbow) {
        float t = ImGui::GetTime() * esp.teammate_color.rainbow_speed;
        esp.teammate_color.r = sinf(t) * 0.5f + 0.5f;
        esp.teammate_color.g = sinf(t + 2.094f) * 0.5f + 0.5f;
        esp.teammate_color.b = sinf(t + 4.188f) * 0.5f + 0.5f;
    }
}

void menu::render_menu() {
    if (!settings.menu_open) return;
    
    update_rainbow_colors(1.0f/60.0f);
    ImGui::GetStyle().ScaleAllSizes(settings.menu_scale);
    
    CGSize screen = [UIScreen mainScreen].bounds.size;
    ImGui::SetNextWindowPos(ImVec2(screen.width/2 - 325*settings.menu_scale, screen.height/2 - 240*settings.menu_scale), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(650*settings.menu_scale, 480*settings.menu_scale));
    
    ImGui::Begin("Hack77 | Midnight", &settings.menu_open,
                 ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar);
    
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(settings.accent_color.r, settings.accent_color.g, settings.accent_color.b, 1.0f));
    ImGui::Text("HACK77 v2.0"); ImGui::SameLine(300*settings.menu_scale);
    ImGui::PopStyleColor();
    ImGui::SameLine();
    if (settings.show_fps) {
        ImGui::Text("FPS: %.0f", ImGui::GetIO().Framerate);
    }
    ImGui::Separator();
    
    const char* tabs[] = {"VISUAL", "AIM", "SETTINGS"};
    ImVec4 btn_col = ImVec4(settings.accent_color.r, settings.accent_color.g, settings.accent_color.b, 0.2f);
    ImVec4 btn_active = ImVec4(settings.accent_color.r, settings.accent_color.g, settings.accent_color.b, 0.7f);
    
    for (int i = 0; i < 3; i++) {
        if (i > 0) ImGui::SameLine(0, 15);
        bool active = (settings.active_tab == i);
        ImGui::PushStyleColor(ImGuiCol_Button, active ? btn_active : btn_col);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, active ? btn_active : ImVec4(settings.accent_color.r, settings.accent_color.g, settings.accent_color.b, 0.4f));
        if (ImGui::Button(tabs[i], ImVec2(195*settings.menu_scale, 35*settings.menu_scale))) {
            settings.active_tab = i;
        }
        ImGui::PopStyleColor(2);
    }
    ImGui::Separator();
    
    switch (settings.active_tab) {
        case 0: render_visual_tab(); break;
        case 1: render_aim_tab(); break;
        case 2: render_settings_tab(); break;
    }
    
    ImGui::End();
}

// ------------------------------------------------------------
// VISUAL TAB
// ------------------------------------------------------------
void menu::render_visual_tab() {
    ImGui::Columns(2, nullptr, false);
    
    ImGui::Checkbox("Enable ESP", &esp.enabled);
    ImGui::Checkbox("2D Box", &esp.box_2d);
    ImGui::Checkbox("3D Box", &esp.box_3d);
    ImGui::Checkbox("Health Bar", &esp.health_bar);
    ImGui::Checkbox("Name", &esp.name);
    ImGui::Checkbox("Distance", &esp.distance);
    ImGui::Checkbox("Skeleton", &esp.skeleton);
    ImGui::Checkbox("Glow", &esp.glow);
    ImGui::Checkbox("Head Circle", &esp.head_circle);
    ImGui::SliderFloat("Max Distance", &esp.max_distance, 0.0f, 300.0f);
    
    ImGui::NextColumn();
    
    ImGui::Text("Enemy Color");
    ImGui::ColorEdit3("##EnemyCol", &esp.enemy_color.r);
    ImGui::Checkbox("Rainbow##Enemy", &esp.enemy_color.rainbow);
    if (esp.enemy_color.rainbow) ImGui::SliderFloat("Speed##Enemy", &esp.enemy_color.rainbow_speed, 0.5f, 3.0f);
    
    ImGui::Text("Teammate Color");
    ImGui::ColorEdit3("##TeamCol", &esp.teammate_color.r);
    ImGui::Checkbox("Rainbow##Team", &esp.teammate_color.rainbow);
    if (esp.teammate_color.rainbow) ImGui::SliderFloat("Speed##Team", &esp.teammate_color.rainbow_speed, 0.5f, 3.0f);
    
    ImGui::Text("Glow Color");
    ImGui::ColorEdit3("##GlowCol", &esp.glow_color.r);
    ImGui::Checkbox("Rainbow##Glow", &esp.glow_color.rainbow);
    if (esp.glow_color.rainbow) ImGui::SliderFloat("Speed##Glow", &esp.glow_color.rainbow_speed, 0.5f, 3.0f);
    
    ImGui::Columns(1);
}

// ------------------------------------------------------------
// AIM TAB
// ------------------------------------------------------------
void menu::render_aim_tab() {
    ImGui::Columns(2, nullptr, false);
    
    ImGui::Checkbox("Enable Aimbot", &aim.enabled);
    ImGui::Checkbox("On Shot Only", &aim.aim_on_shot);
    ImGui::Checkbox("Visible Check", &aim.visible_check);
    ImGui::Checkbox("Touch Assist", &aim.aim_assist_touch);
    ImGui::SliderFloat("FOV", &aim.fov, 0.0f, 90.0f);
    ImGui::SliderFloat("Smoothness", &aim.smooth, 1.0f, 20.0f);
    
    ImGui::NextColumn();
    
    ImGui::Combo("Bone", &aim.bone, "Head\0Neck\0Chest\0Pelvis\0");
    ImGui::SliderFloat("Recoil Comp", &aim.recoil_comp, 0.0f, 1.0f);
    ImGui::Checkbox("Prediction", &aim.prediction);
    if (aim.prediction) ImGui::SliderFloat("Prediction ms", &aim.prediction_ms, 10.0f, 200.0f);
    ImGui::SliderFloat("Touch Radius", &aim.aim_radius, 10.0f, 150.0f);
    
    ImGui::Columns(1);
}

// ------------------------------------------------------------
// SETTINGS TAB
// ------------------------------------------------------------
void menu::render_settings_tab() {
    ImGui::Columns(2, nullptr, false);
    
    ImGui::Text("Menu Accent Color");
    ImGui::ColorEdit3("##Accent", &settings.accent_color.r);
    ImGui::Checkbox("Rainbow Accent", &settings.accent_color.rainbow);
    if (settings.accent_color.rainbow) ImGui::SliderFloat("Speed##Accent", &settings.accent_color.rainbow_speed, 0.5f, 3.0f);
    ImGui::SliderFloat("Opacity", &settings.opacity, 0.3f, 1.0f);
    ImGui::SliderFloat("Menu Scale", &settings.menu_scale, 0.7f, 1.5f);
    ImGui::Checkbox("Show FPS", &settings.show_fps);
    
    ImGui::NextColumn();
    
    const char* langs[] = {"EN", "RU", "CN", "TR", "DE", "FR"};
    int lang_idx = 0;
    for (int i=0; i<6; i++) {
        if (settings.language == langs[i]) { lang_idx = i; break; }
    }
    if (ImGui::Combo("Language", &lang_idx, "EN\0RU\0CN\0TR\0DE\0FR\0")) {
        settings.language = langs[lang_idx];
    }
    
    static char cfg_name[64] = "my_config";
    ImGui::InputText("Config Name", cfg_name, sizeof(cfg_name));
    
    if (ImGui::Button("Save Config", ImVec2(120, 0))) {
        config::save_config(cfg_name);
    }
    ImGui::SameLine();
    if (ImGui::Button("Load Config", ImVec2(120, 0))) {
        config::load_config(cfg_name);
    }
    ImGui::SameLine();
    if (ImGui::Button("Reset Default", ImVec2(120, 0))) {
        config::load_config("default");
    }
    
    ImGui::Columns(1);
}