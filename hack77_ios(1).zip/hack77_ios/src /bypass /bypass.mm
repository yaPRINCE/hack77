#import "bypass.h"
#import <Foundation/Foundation.h>
#import <mach-o/dyld.h>
#import <dlfcn.h>
#import <sys/sysctl.h>
#import <sys/stat.h>
#import <unistd.h>
#import <dirent.h>
#import <string.h>
#import <vector>
#import <string>
#import "../utils/fishhook.h"

namespace bypass {

// ------------------------------------------------------------
// Список скрываемых библиотек
// ------------------------------------------------------------
static const char* hidden_libs[] = {
    "hack77.dylib",
    "hack77",
    "standoff2_ios",
    "substrate",
    "libsubstrate",
    "MobileSubstrate",
    "CydiaSubstrate",
    "libhooker",
    NULL
};

// ------------------------------------------------------------
// Проверка скрытия
// ------------------------------------------------------------
bool is_library_hidden(const char* name) {
    if (!name) return false;
    const char* base = strrchr(name, '/');
    if (base) base++;
    else base = name;
    
    for (int i = 0; hidden_libs[i] != NULL; i++) {
        if (strcasestr(base, hidden_libs[i]) != NULL) {
            return true;
        }
    }
    return false;
}

// ------------------------------------------------------------
// Оригинальные функции
// ------------------------------------------------------------
static int (*orig_open)(const char* path, int flags, mode_t mode) = NULL;
static int (*orig_stat)(const char* path, struct stat* buf) = NULL;
static int (*orig_access)(const char* path, int mode) = NULL;
static int (*orig_sysctl)(int* name, u_int namelen, void* oldp, size_t* oldlenp, void* newp, size_t newlen) = NULL;
static DIR* (*orig_opendir)(const char* name) = NULL;
static struct dirent* (*orig_readdir)(DIR* dirp) = NULL;

// ------------------------------------------------------------
// Перехват open
// ------------------------------------------------------------
static int hooked_open(const char* path, int flags, mode_t mode) {
    if (path && is_library_hidden(path)) {
        errno = ENOENT;
        return -1;
    }
    return orig_open(path, flags, mode);
}

// ------------------------------------------------------------
// Перехват stat
// ------------------------------------------------------------
static int hooked_stat(const char* path, struct stat* buf) {
    if (path && is_library_hidden(path)) {
        errno = ENOENT;
        return -1;
    }
    return orig_stat(path, buf);
}

// ------------------------------------------------------------
// Перехват access
// ------------------------------------------------------------
static int hooked_access(const char* path, int mode) {
    if (path && is_library_hidden(path)) {
        errno = ENOENT;
        return -1;
    }
    return orig_access(path, mode);
}

// ------------------------------------------------------------
// Перехват sysctl (скрываем jailbreak)
// ------------------------------------------------------------
static int hooked_sysctl(int* name, u_int namelen, void* oldp, size_t* oldlenp, void* newp, size_t newlen) {
    if (namelen == 2 && name[0] == CTL_KERN && name[1] == KERN_PROC) {
        if (oldp && oldlenp) {
            *oldlenp = 0;
            return 0;
        }
    }
    return orig_sysctl(name, namelen, oldp, oldlenp, newp, newlen);
}

// ------------------------------------------------------------
// Перехват opendir/readdir
// ------------------------------------------------------------
static DIR* hooked_opendir(const char* name) {
    if (name && is_library_hidden(name)) {
        errno = ENOENT;
        return NULL;
    }
    return orig_opendir(name);
}

static struct dirent* hooked_readdir(DIR* dirp) {
    while (true) {
        struct dirent* entry = orig_readdir(dirp);
        if (!entry) return NULL;
        if (!is_library_hidden(entry->d_name)) {
            return entry;
        }
    }
}

// ------------------------------------------------------------
// Установка всех хуков
// ------------------------------------------------------------
void install_hooks() {
    struct rebinding rebindings[] = {
        {"open", (void*)hooked_open, (void**)&orig_open},
        {"stat", (void*)hooked_stat, (void**)&orig_stat},
        {"access", (void*)hooked_access, (void**)&orig_access},
        {"sysctl", (void*)hooked_sysctl, (void**)&orig_sysctl},
        {"opendir", (void*)hooked_opendir, (void**)&orig_opendir},
        {"readdir", (void*)hooked_readdir, (void**)&orig_readdir}
    };
    
    rebind_symbols(rebindings, sizeof(rebindings) / sizeof(rebindings[0]));
    
    NSLog(@"[Hack77] Bypass hooks installed");
}

// ------------------------------------------------------------
// Обфускация имени библиотеки
// ------------------------------------------------------------
void obfuscate_self() {
    // Простая XOR-обфускация строки "hack77" в памяти
    char* self_name = (char*)strdup("hack77.dylib");
    char key = 0x55;
    for (size_t i = 0; i < strlen(self_name); i++) {
        self_name[i] ^= key;
        key = self_name[i];
    }
    // В продакшене здесь патчинг памяти
    free(self_name);
    NSLog(@"[Hack77] Self obfuscation applied");
}

} // namespace bypass