#pragma once

namespace bypass {
    void install_hooks();
    void obfuscate_self();
    bool is_library_hidden(const char* name);
}